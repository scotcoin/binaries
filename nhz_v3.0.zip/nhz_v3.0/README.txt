Windows: execute run.bat
Linux: exec ./run.sh (preferable in a screen session)

WEB Interface: http://127.0.0.1:7776 (new one)
WEB Interface: http://127.0.0.1:7775 (old one)

Visit: http://nhzcrypto.org/
