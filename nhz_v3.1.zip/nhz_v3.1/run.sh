java -cp nhz.jar:lib/*:conf nhz.Nhz
# NHZ via TOR
#java -DsocksProxyHost=localhost -DsocksProxyPort=9150 -cp nhz.jar:lib/*:conf nhz.Nhz
