Windows: execute run.bat
Linux: exec ./run.sh (preferable in a screen session)

WEB Interface: http://127.0.0.1:7775

Visit: http://nexthorizon.co/