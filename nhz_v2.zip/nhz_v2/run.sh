java -cp nhz.jar:lib/*:conf nhz.Nhz
