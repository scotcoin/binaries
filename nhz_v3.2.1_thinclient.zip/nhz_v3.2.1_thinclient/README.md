NHZ thin client
=====

This is a standalone graphical user interface for the NeXT Horizon p2p network.

You can use any public api server running NHZ. The default setting uses http://api.nhzcrypto.org:7776
To change it edit the NRS.server variable in js/nrs.js